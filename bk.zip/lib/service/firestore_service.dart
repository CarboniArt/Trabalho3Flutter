import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Referência à coleção de patrimônios do usuário atual
  CollectionReference get _patrimoniosCollection {
    final user = _auth.currentUser;
    if (user == null) throw Exception('Usuário não autenticado');
    return _firestore
        .collection('users')
        .doc(user.uid)
        .collection('patrimonios');
  }

  // CREATE - Adicionar novo patrimônio
  Future<void> create(Map<String, dynamic> patrimonio) {
    return _patrimoniosCollection.add({
      ...patrimonio,
      'timestamp': Timestamp.now(),
    });
  }

  // READ - Buscar todos os patrimônios do usuário (Stream em tempo real)
  Stream<QuerySnapshot> read() {
    final patrimonioStream = _patrimoniosCollection
        .orderBy('timestamp', descending: true)
        .snapshots();
    return patrimonioStream;
  }

  // UPDATE - Atualizar patrimônio existente
  Future<void> update(String docID, Map<String, dynamic> patrimonio) {
    return _patrimoniosCollection.doc(docID).update({
      ...patrimonio,
      'timestamp': Timestamp.now(),
    });
  }

  // DELETE - Deletar patrimônio
  Future<void> delete(String docID) {
    return _patrimoniosCollection.doc(docID).delete();
  }

  // GET - Buscar patrimônio específico
  Future<DocumentSnapshot> getPatrimonio(String docID) {
    return _patrimoniosCollection.doc(docID).get();
  }
}
